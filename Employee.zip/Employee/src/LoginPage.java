import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.awt.Window;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginPage extends JFrame {

	private JPanel password;
	private JTextField username;
	private JPasswordField pass;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginPage frame = new LoginPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 663, 349);
		password = new JPanel();
		password.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(password);
		password.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(0, 0, 0, 0);
		password.add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("Login Page");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 26));
		lblNewLabel.setBounds(220, 10, 241, 36);
		password.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("Username");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_2.setBounds(145, 67, 128, 27);
		password.add(lblNewLabel_2);
		
		username = new JTextField();
		username.setBounds(138, 104, 254, 36);
		password.add(username);
		username.setColumns(10);
		
		JLabel lblNewLabel_2_1 = new JLabel("Password");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_2_1.setBounds(145, 157, 128, 27);
		password.add(lblNewLabel_2_1);
		
		pass = new JPasswordField(16);
		pass.setColumns(10);
		pass.setBounds(138, 194, 254, 36);
		password.add(pass);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			
		public void actionPerformed(ActionEvent arg0){
				
				String uname= username.getText();
				String pass1=String.valueOf(pass.getPassword());
				
				if (uname.trim().equals("Pooja")&& pass1.trim().equals("1234"))
				{
				   EmployeeData empData=  new EmployeeData();
				   empData.setVisible(true);
				   
				}
				else if(uname.isEmpty()|| pass1.isEmpty())
				{
					LoginPage login = new LoginPage();
					JOptionPane.showMessageDialog(login, "Userame or Password Cannot be empty");
				}
				else
				{
					LoginPage login = new LoginPage();
					JOptionPane.showMessageDialog(login, "Invalid Username or Password");
				}
				
			}
		});
		btnLogin.setForeground(new Color(0, 0, 0));
		btnLogin.setBackground(new Color(0, 128, 255));
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 17));
		btnLogin.setBounds(232, 268, 128, 34);
		password.add(btnLogin);
	}
}
